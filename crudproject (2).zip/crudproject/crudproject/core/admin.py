from django.contrib import admin
from .models import Item,BlogModel

admin.site.register(Item)
admin.site.register(BlogModel)
# Register your models here.
