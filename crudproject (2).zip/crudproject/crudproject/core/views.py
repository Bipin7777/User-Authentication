from django.shortcuts import render, redirect, get_object_or_404
from .models import BlogModel

# VIEW blogs
def blog_list(request):
    blogs = BlogModel.objects.all()
    return render(request, 'core/blog_list.html', {'blogs': blogs})

# CREATE blog
def blog_create(request):
    if request.method == 'POST':
        BlogModel.objects.create(
            title=request.POST['title'],
            content=request.POST['content'],
            author=request.POST['author']
        )
        return redirect('blog_list')
    return render(request, 'core/blog_create.html')

# UPDATE blog
def blog_update(request, id):
    blog = get_object_or_404(BlogModel, id=id)
    if request.method == 'POST':
        blog.title = request.POST['title']
        blog.content = request.POST['content']
        blog.author = request.POST['author']
        blog.save()
        return redirect('blog_list')
    return render(request, 'core/blog_update.html', {'blog': blog})

# DELETE blog
def blog_delete(request, id):
    blog = get_object_or_404(BlogModel, id=id)
    blog.delete()
    return redirect('blog_list')
