from django import forms
from .models import Item, BlogModel

class ItemForm(forms.ModelForm):

    class Meta:
        model = Item
        fields = ('__all__')


class BlogForm(forms.ModelForm):
    class Meta:
        model = BlogModel
        fields = ('title', 'content', 'author')