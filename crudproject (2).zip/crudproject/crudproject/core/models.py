from django.db import models

# Create your models here.
class Item(models.Model):
    item_id = models.IntegerField()
    name = models.CharField(max_length=100)
    description = models.TextField()
    price = models.FloatField()
    available_stock = models.IntegerField()
    def __str__(self):
        return self.name


class BlogModel(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    author = models.CharField(max_length=100)
    published_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title