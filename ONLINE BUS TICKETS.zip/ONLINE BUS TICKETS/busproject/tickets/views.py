from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from .models import Bus, Route, Schedule, Booking


# ---------------------------
# USER SIDE
# ---------------------------
def index(request):
    return render(request, "index.html")

def home(request):
    schedules = Schedule.objects.all().order_by("date", "time")
    return render(request, "home.html", {"schedules": schedules})


def bus_list(request):
    buses = Bus.objects.all()
    return render(request, "bus_list.html", {"buses": buses})


def search_bus(request):
    routes = Route.objects.all()
    schedules = None

    if request.method == "POST":
        from_location = request.POST.get("from_location")
        to_location = request.POST.get("to_location")
        date = request.POST.get("date")

        schedules = Schedule.objects.filter(
            route__from_location__icontains=from_location,
            route__to_location__icontains=to_location,
            date=date
        )

    return render(request, "search.html", {"routes": routes, "schedules": schedules})


@login_required
def book_ticket(request, schedule_id):
    schedule = get_object_or_404(Schedule, id=schedule_id)

    if request.method == "POST":
        seats = int(request.POST.get("seats"))

        if seats <= 0:
            messages.error(request, "Seats must be greater than 0")
            return redirect("book_ticket", schedule_id=schedule_id)

        if seats > schedule.available_seats:
            messages.error(request, "Not enough seats available!")
            return redirect("book_ticket", schedule_id=schedule_id)

        total_price = seats * schedule.bus.price

        Booking.objects.create(
            user=request.user,
            schedule=schedule,
            seats_booked=seats,
            total_price=total_price
        )

        schedule.available_seats -= seats
        schedule.save()

        messages.success(request, "Ticket booked successfully!")
        return redirect("my_tickets")

    return render(request, "book_ticket.html", {"schedule": schedule})


@login_required
def my_tickets(request):
    bookings = Booking.objects.filter(user=request.user).order_by("-booked_at")
    return render(request, "my_tickets.html", {"bookings": bookings})


@login_required
def cancel_ticket(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)

    schedule = booking.schedule
    schedule.available_seats += booking.seats_booked
    schedule.save()

    booking.delete()
    messages.success(request, "Ticket cancelled successfully!")
    return redirect("my_tickets")


# ---------------------------
# ADMIN DASHBOARD SIDE
# ---------------------------

def is_admin(user):
    return user.is_superuser or user.is_staff


@user_passes_test(is_admin)
def admin_dashboard(request):
    total_buses = Bus.objects.count()
    total_routes = Route.objects.count()
    total_schedules = Schedule.objects.count()
    total_bookings = Booking.objects.count()

    bookings = Booking.objects.all().order_by("-booked_at")

    context = {
        "total_buses": total_buses,
        "total_routes": total_routes,
        "total_schedules": total_schedules,
        "total_bookings": total_bookings,
        "bookings": bookings,
    }
    return render(request, "dashboard.html", context)


@user_passes_test(is_admin)
def add_bus(request):
    if request.method == "POST":
        Bus.objects.create(
            bus_name=request.POST.get("bus_name"),
            bus_number=request.POST.get("bus_number"),
            total_seats=request.POST.get("total_seats"),
            price=request.POST.get("price"),
        )
        messages.success(request, "Bus added successfully!")
        return redirect("admin_dashboard")

    return render(request, "add_bus.html")


@user_passes_test(is_admin)
def add_route(request):
    if request.method == "POST":
        Route.objects.create(
            from_location=request.POST.get("from_location"),
            to_location=request.POST.get("to_location"),
        )
        messages.success(request, "Route added successfully!")
        return redirect("admin_dashboard")

    return render(request, "add_route.html")


@user_passes_test(is_admin)
def add_schedule(request):
    buses = Bus.objects.all()
    routes = Route.objects.all()

    if request.method == "POST":
        bus = Bus.objects.get(id=request.POST.get("bus"))
        route = Route.objects.get(id=request.POST.get("route"))

        Schedule.objects.create(
            bus=bus,
            route=route,
            date=request.POST.get("date"),
            time=request.POST.get("time"),
            available_seats=request.POST.get("available_seats"),
        )

        messages.success(request, "Schedule added successfully!")
        return redirect("admin_dashboard")

    return render(request, "add_schedule.html", {"buses": buses, "routes": routes})



