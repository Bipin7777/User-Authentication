from django.urls import path
from . import views

urlpatterns = [
    # User Side
    path('', views.home, name="home"),
    path('', views.index, name='index'),
    path('buses/', views.bus_list, name="bus_list"),
    path('search/', views.search_bus, name="search_bus"),
    path('book/<int:schedule_id>/', views.book_ticket, name="book_ticket"),
    path('my-tickets/', views.my_tickets, name="my_tickets"),
    path('cancel/<int:booking_id>/', views.cancel_ticket, name="cancel_ticket"),

    # Admin Dashboard
    path('dashboard/', views.admin_dashboard, name="admin_dashboard"),
    path('dashboard/add-bus/', views.add_bus, name="add_bus"),
    path('dashboard/add-route/', views.add_route, name="add_route"),
    path('dashboard/add-schedule/', views.add_schedule, name="add_schedule"),
]
