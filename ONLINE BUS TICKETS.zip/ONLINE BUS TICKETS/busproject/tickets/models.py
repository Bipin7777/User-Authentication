from django.db import models
from django.contrib.auth.models import User


class Bus(models.Model):
    bus_name = models.CharField(max_length=100)
    bus_number = models.CharField(max_length=50, unique=True)
    total_seats = models.IntegerField()
    price = models.IntegerField()

    def __str__(self):
        return f"{self.bus_name} ({self.bus_number})"


class Route(models.Model):
    from_location = models.CharField(max_length=100)
    to_location = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.from_location} → {self.to_location}"


class Schedule(models.Model):
    bus = models.ForeignKey(Bus, on_delete=models.CASCADE)
    route = models.ForeignKey(Route, on_delete=models.CASCADE)
    date = models.DateField()
    time = models.TimeField()
    available_seats = models.IntegerField()

    def __str__(self):
        return f"{self.bus} | {self.route} | {self.date} {self.time}"


class Booking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    schedule = models.ForeignKey(Schedule, on_delete=models.CASCADE)
    seats_booked = models.IntegerField()
    total_price = models.IntegerField()
    booked_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} booked {self.seats_booked} seats"
